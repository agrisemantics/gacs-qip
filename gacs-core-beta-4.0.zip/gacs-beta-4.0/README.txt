This is the GACS Beta 4.0 release.
It contains the following RDF/SKOS files:

gacs-beta-4.0.ttl		Concept scheme using Turtle syntax.
gacs-beta-4.0.rdf		Same as above, but uses RDF/XML syntax.

You should only need either .ttl or .rdf

The files contain the following information within a single RDF graph:
- SKOS Core and SKOS XL labels
- original scientific names (with @zxx-x-taxon language tag)
- expanded scientific names in many Latin alphabet languages
- thematic groups
- Agrisemantics vocabulary with class and property definitions
